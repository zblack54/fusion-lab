use fusion_lab::{Config, DeliveryPlan, ReplayModel, ReplayResult, Trace, replay_delivery, run};
use std::{error::Error, hint::black_box, io::{self, Write}};
fn equal(a: &ReplayResult, b: &ReplayResult) {
    assert_eq!(a.snapshots().len(), b.snapshots().len());
    for (a,b) in a.snapshots().iter().zip(b.snapshots()) {
        assert_eq!(a.tick(),b.tick());
        let values=|s: &fusion_lab::ReplaySnapshot| s.estimate().position.into_iter().chain(s.estimate().velocity).chain(s.covariance().iter().flatten().copied()).chain(s.held_position()).chain(s.integrated_position()).map(f64::to_bits).collect::<Vec<_>>();
        assert_eq!(values(a),values(b));
    }
    assert_eq!(a.ledger().len(), b.ledger().len());
    for (a,b) in a.ledger().iter().zip(b.ledger()) {
        assert_eq!((a.id(),a.sample_tick(),a.planned_arrival_tick(),a.decision_tick(),a.outcome(),a.queue_occupancy()),(b.id(),b.sample_tick(),b.planned_arrival_tick(),b.decision_tick(),b.outcome(),b.queue_occupancy()));
    }
    assert_eq!(a.arrival_order(),b.arrival_order());
}
fn main() -> Result<(),Box<dyn Error>> {
    let duration=match std::env::args().nth(1).as_deref() { Some("warmup")=>1,Some("maximum")=>3600,_=>return Err("expected warmup or maximum".into()) };
    let config=Config { duration_seconds:duration, outage:None, ..Config::default() };
    let source=run(&config)?;
    let model=ReplayModel::new(1.0,0.15,0.1)?;
    let trace=Trace::from_samples(duration,&source.samples,DeliveryPlan::new(500,500,128,None,None)?)?;
    let result=replay_delivery(&model,&trace)?;
    let encoded=trace.encode_tsv(&model)?;
    let ledger=result.encode_ledger_tsv()?;
    let (decoded_model,decoded)=Trace::decode_tsv(&encoded)?;
    assert_eq!(trace.duration_seconds(),decoded.duration_seconds());
    assert_eq!(trace.pending_capacity(),decoded.pending_capacity());
    for sensor in [fusion_lab::Sensor::Position,fusion_lab::Sensor::Velocity] { assert_eq!(trace.drop_every(sensor),decoded.drop_every(sensor)); }
    assert_eq!(trace.observations().len(),decoded.observations().len());
    for (a,b) in trace.observations().iter().zip(decoded.observations()) {
        assert_eq!((a.id(),a.sample_tick(),a.planned_arrival_tick()),(b.id(),b.sample_tick(),b.planned_arrival_tick()));
        assert_eq!(a.value().map(f64::to_bits),b.value().map(f64::to_bits));
    }
    assert_eq!([model.assumed_position_sigma(),model.assumed_velocity_sigma(),model.acceleration_density()].map(f64::to_bits),[decoded_model.assumed_position_sigma(),decoded_model.assumed_velocity_sigma(),decoded_model.acceleration_density()].map(f64::to_bits));
    let regenerated=decoded.encode_tsv(&decoded_model)?;
    assert_eq!(encoded,regenerated);
    let replayed=replay_delivery(&decoded_model,&decoded)?;
    equal(&result,&replayed);
    let regenerated_ledger=replayed.encode_ledger_tsv()?;
    assert_eq!(ledger,regenerated_ledger);
    if duration==3600 { assert_eq!(trace.observations().len(),90002); assert_eq!(source.samples.len(),360001); }
    println!("COMPLETE\t{}\t{}\t{}\t{}\t{}",duration,trace.observations().len(),result.snapshots().len(),encoded.len(),ledger.len());
    io::stdout().flush()?;
    // Every required allocation remains live across the owner's held-HWM read.
    black_box((&source,&trace,&result,&encoded,&ledger,&decoded,&replayed,&regenerated,&regenerated_ledger));
    let mut ack=String::new();
    io::stdin().read_line(&mut ack)?;
    if ack!="release\n" { return Err("missing owner release acknowledgement".into()); }
    black_box((&source,&trace,&result,&encoded,&ledger,&decoded,&replayed,&regenerated,&regenerated_ledger));
    Ok(())
}
